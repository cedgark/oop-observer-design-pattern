public abstract class MusicCatalogueObserver {
  public abstract void update();
}
